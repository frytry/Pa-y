var express     = require("express"),
    app         = express(),
    bodyParser  = require("body-parser"),
    flash       = require("connect-flash"),
    methodOverride = require("method-override");

const stripe = require('stripe')('sk_test_vybeuCt5e9eozzALDGMhKXig00r5lfN9zk');

app.use(express.json());
app.use(express.urlencoded({extended: true}));
app.set("view engine", "ejs");
app.use(express.static(__dirname + "/public"));
app.use(methodOverride("_method"));
app.use(flash());


// POST pay
app.post('/pay', async (req, res) => {
    const { paymentMethodId, items, currency } = req.body;
    const amount = 200;
    try {
      // Create new PaymentIntent with a PaymentMethod ID from the client.
      const intent = await stripe.paymentIntents.create({
        amount,
        currency,
        payment_method: paymentMethodId,
        error_on_requires_action: true,
        confirm: true
      });
      console.log("💰 Payment received!");
      res.send({ clientSecret: intent.client_secret });
    } catch (e) {
      if (e.code === "authentication_required") {
        res.send({
          error:
            "This card requires authentication in order to proceeded. Please use a different card."
        });
      } else {
        res.send({ error: e.message });
      }
    }
});


app.listen(8080, process.env.IP, function(){
   console.log("StripeDemo");
});
